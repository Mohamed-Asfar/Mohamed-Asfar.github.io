$(document).ready(function() {

    // preload all six images
    var images = [];

    //for(var i = 0; i < 6; i++) {
    //    images[i] = new Image();
    //    images[i].src = preload.arguments[i];
    //}

    $("#image_list a").click(function (evt) {

        // preventing default loading of the links
        evt.preventDefault();

        // make the caption variable to make calling the caption simpler
        var captionForPicture = $(this).attr("title");

        // make the imageLink variable to make calling the picture simpler
        var imageLink = $(this).attr("href");

        //fade out the old capture
        $("#caption").fadeOut(1000, function(){

            $("#caption").text(captionForPicture).fadeIn(1000);

        });

        // fade out old picture
        $("#image").fadeOut(1000, function(){

            $("#image").attr("src", imageLink).fadeIn(1000);

        });

    }); // end click


    // focus on the first picture
    $("li:first-child a").focus();

    // bring in the new picture
    $("#image").hide().fadeIn(1000);

    // bring in the new caption
    $("#caption").hide().fadeIn(1000);

}); // end ready